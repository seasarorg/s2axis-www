@javax.xml.bind.annotation.XmlSchema(namespace = "http://ex02.jaxws.examples.axis2.remoting.seasar.org/")
package org.seasar.remoting.axis2.examples.jaxws.ex02.client;
