package org.seasar.remoting.axis2.examples.ex03;

public interface BeanEcho {
    
    EchoDto echo(EchoDto echoDto);

}
